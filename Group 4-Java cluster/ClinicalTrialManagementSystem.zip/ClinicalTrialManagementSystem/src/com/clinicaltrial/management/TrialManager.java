package com.clinicaltrial.management;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TrialManager {

    // Add a new Trial
    public void addTrial(Trial trial) {
        String query = "INSERT INTO Trial (trial_name, start_date, end_date, status) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, trial.getTrialName());
            stmt.setDate(2, new java.sql.Date(trial.getStartDate().getTime()));
            stmt.setDate(3, new java.sql.Date(trial.getEndDate().getTime()));
            stmt.setString(4, trial.getStatus());
            stmt.executeUpdate();

            System.out.println("Trial added successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to add trial.");
        }
    }

    // View all Trials
    public List<Trial> viewAllTrials() {
        List<Trial> trials = new ArrayList<>();
        String query = "SELECT * FROM Trial";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int trialId = rs.getInt("trial_id");
                String trialName = rs.getString("trial_name");
                Date startDate = rs.getDate("start_date");
                Date endDate = rs.getDate("end_date");
                String status = rs.getString("status");

                trials.add(new Trial(trialId, trialName, startDate, endDate, status));
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to retrieve trials.");
        }

        return trials;
    }

    // Update Trial information
    public void updateTrial(Trial trial) {
        String query = "UPDATE Trial SET trial_name = ?, start_date = ?, end_date = ?, status = ? WHERE trial_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, trial.getTrialName());
            stmt.setDate(2, new java.sql.Date(trial.getStartDate().getTime()));
            stmt.setDate(3, new java.sql.Date(trial.getEndDate().getTime()));
            stmt.setString(4, trial.getStatus());
            stmt.setInt(5, trial.getTrialId());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Trial updated successfully!");
            } else {
                System.out.println("Trial not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to update trial.");
        }
    }

    // Delete a Trial
    public void deleteTrial(int trialId) {
        String query = "DELETE FROM Trial WHERE trial_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, trialId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Trial deleted successfully!");
            } else {
                System.out.println("Trial not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to delete trial.");
        }
    }
}
