package com.clinicaltrial.management;
import java.util.Date;

/**
 * This class represents a data record associated with a participant in a  
 * trial according to the case study given 
 * so i choose to make it a clinical trial data looking thing.
 * It contains attributes for data ID, participant ID, data date, data value, and data type.
 */

public class Data {
    private int dataId;
    private int participantId;
    private Date dataDate;
    private String dataValue;
    private String dataType;

    // Constructor
    public Data(int dataId, int participantId, Date dataDate, String dataValue, String dataType) {
        this.dataId = dataId;
        this.participantId = participantId;
        this.dataDate = dataDate;
        this.dataValue = dataValue;
        this.dataType = dataType;
    }

    // Getters and Setters
    public int getDataId() {
        return dataId;
    }

    public void setDataId(int dataId) {
        this.dataId = dataId;
    }

    public int getParticipantId() {
        return participantId;
    }

    public void setParticipantId(int participantId) {
        this.participantId = participantId;
    }

    public Date getDataDate() {
        return dataDate;
    }

    public void setDataDate(Date dataDate) {
        this.dataDate = dataDate;
    }

    public String getDataValue() {
        return dataValue;
    }

    public void setDataValue(String dataValue) {
        this.dataValue = dataValue;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    @Override
    public String toString() {
        return "Data ID: " + dataId + ", Participant ID: " + participantId + ", Data Date: " + dataDate +
               ", Data Value: " + dataValue + ", Data Type: " + dataType;
    }
}
