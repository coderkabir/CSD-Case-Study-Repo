package com.clinicaltrial.management;
import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class ClinicalTrialManagementSystem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);// Create a scanner for user input
        TrialManager trialManager = new TrialManager();
        ParticipantManager participantManager = new ParticipantManager();
        DataManager dataManager = new DataManager();// Initialize managers for handling trials, participants, and data
        // Main loop to display the menu and handle user input
        while (true) {
            System.out.println("Clinical Trial Management System");
            System.out.println("1. Manage Trials");
            System.out.println("2. Manage Participants");
            System.out.println("3. Manage Data");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
         // Handle user selection
            switch (choice) {
                case 1:// Manage trials, participant as follows
                    manageTrials(trialManager, scanner);
                    break;
                case 2:
                    manageParticipants(participantManager, scanner);
                    break;
                case 3:
                    manageData(dataManager, scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
 // Method to manage trials
    private static void manageTrials(TrialManager trialManager, Scanner scanner) {
        while (true) {
            System.out.println("\nTrial Management");
            System.out.println("1. Add Trial");
            System.out.println("2. View All Trials");
            System.out.println("3. Update Trial");
            System.out.println("4. Delete Trial");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addTrial(trialManager, scanner);
                    break;
                case 2:
                    List<Trial> trials = trialManager.viewAllTrials();
                    trials.forEach(System.out::println);
                    break;
                case 3:
                    updateTrial(trialManager, scanner);
                    break;
                case 4:
                    deleteTrial(trialManager, scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void addTrial(TrialManager trialManager, Scanner scanner) {
        System.out.print("Enter trial name: ");
        String trialName = scanner.next();
        System.out.print("Enter start date (yyyy-mm-dd): ");
        String startDateStr = scanner.next();
        System.out.print("Enter end date (yyyy-mm-dd): ");
        String endDateStr = scanner.next();
        System.out.print("Enter status (Planned, In Progress, Completed): ");
        String status = scanner.next();
     // Method to add a new trial
        Trial trial = new Trial(0, trialName, Date.valueOf(startDateStr), Date.valueOf(endDateStr), status);
        trialManager.addTrial(trial);
    }
 // Method to update an existing trial
    private static void updateTrial(TrialManager trialManager, Scanner scanner) {
        System.out.print("Enter trial ID to update: ");
        int trialId = scanner.nextInt();
        System.out.print("Enter new trial name: ");
        String trialName = scanner.next();
        System.out.print("Enter new start date (yyyy-mm-dd): ");
        String startDateStr = scanner.next();
        System.out.print("Enter new end date (yyyy-mm-dd): ");
        String endDateStr = scanner.next();
        System.out.print("Enter new status (Planned, In Progress, Completed): ");
        String status = scanner.next();

        Trial trial = new Trial(trialId, trialName, Date.valueOf(startDateStr), Date.valueOf(endDateStr), status);
        trialManager.updateTrial(trial);
    }

    private static void deleteTrial(TrialManager trialManager, Scanner scanner) {
        System.out.print("Enter trial ID to delete: ");
        int trialId = scanner.nextInt();
        trialManager.deleteTrial(trialId);
    }
 // Method to manage participants
    private static void manageParticipants(ParticipantManager participantManager, Scanner scanner) {
        while (true) {
            System.out.println("\nParticipant Management");
            System.out.println("1. Add Participant");
            System.out.println("2. View All Participants");
            System.out.println("3. Update Participant");
            System.out.println("4. Delete Participant");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addParticipant(participantManager, scanner);
                    break;
                case 2:
                    List<Participant> participants = participantManager.viewAllParticipants();
                    participants.forEach(System.out::println);
                    break;
                case 3:
                    updateParticipant(participantManager, scanner);
                    break;
                case 4:
                    deleteParticipant(participantManager, scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
 // Method to add a new participant
    private static void addParticipant(ParticipantManager participantManager, Scanner scanner) {
        System.out.print("Enter participant name: ");
        String participantName = scanner.next();
        System.out.print("Enter date of birth (yyyy-mm-dd): ");
        String dateOfBirthStr = scanner.next();
        System.out.print("Enter contact number: ");
        String contactNumber = scanner.next();
        System.out.print("Enter email: ");
        String email = scanner.next();
        System.out.print("Enter trial ID: ");
        int trialId = scanner.nextInt();

        Participant participant = new Participant(0, participantName, Date.valueOf(dateOfBirthStr), contactNumber, email, trialId);
        participantManager.addParticipant(participant);
    }
 // Method to update an existing participant
    private static void updateParticipant(ParticipantManager participantManager, Scanner scanner) {
        System.out.print("Enter participant ID to update: ");
        int participantId = scanner.nextInt();
        System.out.print("Enter new participant name: ");
        String participantName = scanner.next();
        System.out.print("Enter new date of birth (yyyy-mm-dd): ");
        String dateOfBirthStr = scanner.next();
        System.out.print("Enter new contact number: ");
        String contactNumber = scanner.next();
        System.out.print("Enter new email: ");
        String email = scanner.next();
        System.out.print("Enter new trial ID: ");
        int trialId = scanner.nextInt();

        Participant participant = new Participant(participantId, participantName, Date.valueOf(dateOfBirthStr), contactNumber, email, trialId);
        participantManager.updateParticipant(participant);
    }

    private static void deleteParticipant(ParticipantManager participantManager, Scanner scanner) {
        System.out.print("Enter participant ID to delete: ");
        int participantId = scanner.nextInt();
        participantManager.deleteParticipant(participantId);
    }
 // Method to manage data
    private static void manageData(DataManager dataManager, Scanner scanner) {
        while (true) {
            System.out.println("\nData Management");
            System.out.println("1. Add Data");
            System.out.println("2. View All Data");
            System.out.println("3. Update Data");
            System.out.println("4. Delete Data");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addData(dataManager, scanner);
                    break;
                case 2:
                    List<Data> dataList = dataManager.viewAllData();
                    dataList.forEach(System.out::println);
                    break;
                case 3:
                    updateData(dataManager, scanner);
                    break;
                case 4:
                    deleteData(dataManager, scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void addData(DataManager dataManager, Scanner scanner) {
        System.out.print("Enter participant ID: ");
        int participantId = scanner.nextInt();
        System.out.print("Enter data date (yyyy-mm-dd): ");
        String dataDateStr = scanner.next();
        System.out.print("Enter data value: ");
        String dataValue = scanner.next();
        System.out.print("Enter data type: ");
        String dataType = scanner.next();

        Data data = new Data(0, participantId, Date.valueOf(dataDateStr), dataValue, dataType);
        dataManager.addData(data);
    }

    private static void updateData(DataManager dataManager, Scanner scanner) {
        System.out.print("Enter data ID to update: ");
        int dataId = scanner.nextInt();
        System.out.print("Enter new participant ID: ");
        int participantId = scanner.nextInt();
        System.out.print("Enter new data date (yyyy-mm-dd): ");
        String dataDateStr = scanner.next();
        System.out.print("Enter new data value: ");
        String dataValue = scanner.next();
        System.out.print("Enter new data type: ");
        String dataType = scanner.next();

        Data data = new Data(dataId, participantId, Date.valueOf(dataDateStr), dataValue, dataType);
        dataManager.updateData(data);
    }

    private static void deleteData(DataManager dataManager, Scanner scanner) {
        System.out.print("Enter data ID to delete: ");
        int dataId = scanner.nextInt();
        dataManager.deleteData(dataId);
    }
}
