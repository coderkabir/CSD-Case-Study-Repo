package com.clinicaltrial.management;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DataManager class is responsible for handling all database operations related to the 'Data' entity.
 * This includes adding, viewing, updating, and deleting data records from the database.
 */

public class DataManager {

    // Add new Data
    public void addData(Data data) {
        String query = "INSERT INTO Data (participant_id, data_date, data_value, data_type) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, data.getParticipantId());
            stmt.setDate(2, new java.sql.Date(data.getDataDate().getTime()));
            stmt.setString(3, data.getDataValue());
            stmt.setString(4, data.getDataType());
            stmt.executeUpdate();

            System.out.println("Data added successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to add data.");
        }
    }

    // View all Data
    public List<Data> viewAllData() {
        List<Data> dataList = new ArrayList<>();
        String query = "SELECT * FROM Data";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int dataId = rs.getInt("data_id");
                int participantId = rs.getInt("participant_id");
                Date dataDate = rs.getDate("data_date");
                String dataValue = rs.getString("data_value");
                String dataType = rs.getString("data_type");

                dataList.add(new Data(dataId, participantId, dataDate, dataValue, dataType));
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to retrieve data.");
        }

        return dataList;
    }

    // Update Data information
    public void updateData(Data data) {
        String query = "UPDATE Data SET participant_id = ?, data_date = ?, data_value = ?, data_type = ? WHERE data_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, data.getParticipantId());
            stmt.setDate(2, new java.sql.Date(data.getDataDate().getTime()));
            stmt.setString(3, data.getDataValue());
            stmt.setString(4, data.getDataType());
            stmt.setInt(5, data.getDataId());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Data updated successfully!");
            } else {
                System.out.println("Data not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to update data.");
        }
    }

    // Delete Data
    public void deleteData(int dataId) {
        String query = "DELETE FROM Data WHERE data_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, dataId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Data deleted successfully!");
            } else {
                System.out.println("Data not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to delete data.");
        }
    }
}

