package com.clinicaltrial.management;
import java.util.Date;

public class Trial {
    private int trialId;
    private String trialName;
    private Date startDate;
    private Date endDate;
    private String status;

    // Constructor
    public Trial(int trialId, String trialName, Date startDate, Date endDate, String status) {
        this.trialId = trialId;
        this.trialName = trialName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
    }

    // Getters and Setters
    public int getTrialId() {
        return trialId;
    }

    public void setTrialId(int trialId) {
        this.trialId = trialId;
    }

    public String getTrialName() {
        return trialName;
    }

    public void setTrialName(String trialName) {
        this.trialName = trialName;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Trial ID: " + trialId + ", Name: " + trialName + ", Start Date: " + startDate + 
               ", End Date: " + endDate + ", Status: " + status;
    }
}
