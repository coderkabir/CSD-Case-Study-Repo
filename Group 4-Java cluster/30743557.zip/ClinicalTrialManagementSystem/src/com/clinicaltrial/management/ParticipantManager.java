package com.clinicaltrial.management;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ParticipantManager {

    // Add a new Participant
    public void addParticipant(Participant participant) {
        String query = "INSERT INTO Participant (participant_name, date_of_birth, contact_number, email, trial_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, participant.getParticipantName());
            stmt.setDate(2, new java.sql.Date(participant.getDateOfBirth().getTime()));
            stmt.setString(3, participant.getContactNumber());
            stmt.setString(4, participant.getEmail());
            stmt.setInt(5, participant.getTrialId());
            stmt.executeUpdate();

            System.out.println("Participant added successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to add participant.");
        }
    }

    // View all Participants
    public List<Participant> viewAllParticipants() {
        List<Participant> participants = new ArrayList<>();
        String query = "SELECT * FROM Participant";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int participantId = rs.getInt("participant_id");
                String participantName = rs.getString("participant_name");
                Date dateOfBirth = rs.getDate("date_of_birth");
                String contactNumber = rs.getString("contact_number");
                String email = rs.getString("email");
                int trialId = rs.getInt("trial_id");

                participants.add(new Participant(participantId, participantName, dateOfBirth, contactNumber, email, trialId));
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to retrieve participants.");
        }

        return participants;
    }

    // Update Participant information
    public void updateParticipant(Participant participant) {
        String query = "UPDATE Participant SET participant_name = ?, date_of_birth = ?, contact_number = ?, email = ?, trial_id = ? WHERE participant_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, participant.getParticipantName());
            stmt.setDate(2, new java.sql.Date(participant.getDateOfBirth().getTime()));
            stmt.setString(3, participant.getContactNumber());
            stmt.setString(4, participant.getEmail());
            stmt.setInt(5, participant.getTrialId());
            stmt.setInt(6, participant.getParticipantId());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Participant updated successfully!");
            } else {
                System.out.println("Participant not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to update participant.");
        }
    }

    // Delete a Participant
    public void deleteParticipant(int participantId) {
        String query = "DELETE FROM Participant WHERE participant_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, participantId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Participant deleted successfully!");
            } else {
                System.out.println("Participant not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to delete participant.");
        }
    }
}
